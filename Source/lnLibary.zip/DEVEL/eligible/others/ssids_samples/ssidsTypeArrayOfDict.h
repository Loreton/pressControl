//
// updated by ...: Loreto Notarantonio
// Date .........: 06-01-2025 09.13.29
//

    // #####################################################
    // # to one line
    // #          https://jsonformatter.curiousconcept.com
    // #####################################################
    String SSID_definitions = R"(
        {
            "ssids": [

                {
                    "ssid": "Casetta",
                    "password": "psw_Casetta"
                },
                {
                    "ssid": "cpe210",
                    "password" :"psw_cpe210"
                },
                {
                    "ssid": "OpenWrt",
                    "password" :"psw_OpenWrt"
                },
                {
                    "ssid": "LoretoHotSpot",
                    "password": "psw_LoretoHotSpot"
                },
                {
                    "ssid": "Loreto.net",
                    "password": "psw_Loreto.net"
                },
                {
                    "ssid": "WebPocket-4545",
                    "password": "psw_WebPocket-4545"
                },
                {
                    "ssid": "LnFP25",
                    "password": "psw_LnFP25"
                }
            ]
        }
    )";
    String SSID_definitions_one_line = R"()";
