//
// updated by ...: Loreto Notarantonio
// Date .........: 06-01-2025 09.14.21
//
    // #####################################################
    // # to one line
    // #          https://jsonformatter.curiousconcept.com
    // #####################################################
    String SSID_definitions = R"(
        {
            "ssids": [
                ["Casetta",         "psw_Casetta"],
                ["cpe210",          "psw_cpe210"],
                ["OpenWrt",         "psw_OpenWrt"],
                ["LoretoHotSpot",   "psw_LoretoHotSpot"],
                ["Loreto.net",      "psw_Loreto.net"],
                ["WebPocket-4545",  "psw_WebPocket-4545"],
                ["LnFP25",          "psw_LnFP25"]
            ]
        }
    )";

    String SSID_definitions_one_line = R"()";

