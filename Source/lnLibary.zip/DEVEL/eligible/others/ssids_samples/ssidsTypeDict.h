//
// updated by ...: Loreto Notarantonio
// Date .........: 06-01-2025 11.48.42
//




    // #define MAX_SSIDS 10

#ifdef __LN_WIFI_CPP__


    // #####################################################
    // # to one line: https://jsonformatter.curiousconcept.com
    // #####################################################

    String SSID_Dict = R"(
        {
            "ssids": {
                "Casetta":         "Casetta.Adsl",
                "cpe210":          "Loreto.CPE210",
                "OpenWrt":         "Casetta.Adsl",
                "LoretoHotSpot":   "Loretohs",
                "Loreto.net":      "Loretonet",
                "WebPocket-4545":  "BBBA6CAC",
                "LnFP25":          "Pina,.Adsl,.1932",
                "LnA07":           "7redkagee3pgr8o0"
            }
        }
    )";

    #define MAX_SSIDS 10
    String SSID_definitions_one_line = R"({"ssids":{"Casetta":"Casetta.Adsl","cpe210":"Loreto.CPE210","OpenWrt":"Casetta.Adsl","LoretoHotSpot":"Loretohs","Loreto.net":"Loretonet","WebPocket-4545":"BBBA6CAC","LnFP25":"Pina,.Adsl,.1932","LnA07":"7redkagee3pgr8o0"}})";


#else
    extern String SSID_definitions_one_line;


#endif